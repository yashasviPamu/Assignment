package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RadioGroup radioGroup;
    RadioButton rButton1,rButton2;
    Button next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
        rButton1=(RadioButton)findViewById(R.id.rButton1);
        rButton2=(RadioButton)findViewById(R.id.rButton2);
        next=(Button)findViewById(R.id.button);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rButton1.isChecked()){
                    Intent intent = new Intent(getApplicationContext(), DrawingActivity.class);
                    startActivity(intent);
                }else if(rButton2.isChecked()){
                    Intent intent = new Intent(getApplicationContext(), GameScores.class);
                    startActivity(intent);
                }

            }
        });

    }
}
