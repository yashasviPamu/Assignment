package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
public class GameScores extends AppCompatActivity {
    TextView score1, score2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_scores);

        score1=findViewById(R.id.t11);
        score2=findViewById(R.id.t21);
        if(savedInstanceState!=null)
        {

        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);

        int mode= AppCompatDelegate.getDefaultNightMode();
        if(mode==AppCompatDelegate.MODE_NIGHT_YES)
        {
            //menu.getItem(0).setTitle("Day Theme");
            menu.findItem(R.id.dark).setTitle("Day Theme");
        }
        else
            menu.findItem(R.id.dark).setTitle("Dark Theme");


        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("K1",Integer.parseInt((score1.getText().toString())));
        outState.putInt("K2",Integer.parseInt((score2.getText().toString())));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.dark)
        {
            Toast.makeText(this,"Menu item clicked",Toast.LENGTH_SHORT).show();

            int mode= AppCompatDelegate.getDefaultNightMode();
            if(mode==AppCompatDelegate.MODE_NIGHT_YES)
            {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
            else
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

            recreate();
        }
        return true;

    }

    public void DoIncrease(View view) {
        int id=view.getId();
        int c;
        switch(id)
        {
            case R.id.i11:
                c=Integer.parseInt(score1.getText().toString());
                c=c+1;
                score1.setText(Integer.toString(c));
                break;
            case R.id.i21:
                c=Integer.parseInt(score2.getText().toString());
                c=c+1;
                score2.setText(Integer.toString(c));
        }
    }

    public void DoDecrease(View view) {
        int id=view.getId();
        int c;
        switch(id)
        {
            case R.id.i12:
                c=Integer.parseInt(score1.getText().toString());
                c=c-1;
                score1.setText(Integer.toString(c));
                break;
            case R.id.i22:
                c=Integer.parseInt(score2.getText().toString());
                c=c-1;
                score2.setText(Integer.toString(c));
        }
    }
}
